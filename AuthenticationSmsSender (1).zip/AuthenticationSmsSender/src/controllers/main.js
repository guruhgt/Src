const router = require('express').Router();

router.get("/", (_, res) => {
    res.send(`<!DOCTYPE html>
    <html>
    
    <head>
        <title>CIGNA</title>
        <link rel="stylesheet" href="./fonts/font.css" />
        <link rel="stylesheet" href="./css/styles.css" />
        <script src="./js/scripts.js"></script>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>
    
    
    <body onload="onload()">
    
        <div class="main-wrapper">
            <div class="wrapper">
                <header>
                    <div class="logo">
                        <img src="./images/cigna-logo.png" alt="Cigna Logo">
                    </div>
                    <div class="title">
                        <b>EVERNORTH</b> OUTBOUND TEXTING
                    </div>
                </header>
                <div class="content-wrapper">
                    <h2>Customer Information</h2>
                    <form id="myForm">
                        <div class="form-header">
                            <div class="input-flex">
                                <span>Phone Number</span>
                                <div class="number-input">
                                    <span class="country-code">+1</span>
                                    <input type="text" id="phone" placeholder="(123) 456-5555" />
                                </div>
                            </div>
                            <div class="input-flex checkbox">
                                <label class="checkbox-flex">
                                    <input type="radio" name="choice" id="EAP" checked />
                                    <span class="checkmark"></span>
                                    <span>EAP Auth Code</span>
                                </label>
                                <label class="checkbox-flex">
                                    <input type="radio" name="choice" id="providerReferrals" />
                                    <span class="checkmark"></span>
                                    <span>Provider Referrals</span>
                                </label>
                            </div>
                            <div id="auth-ctr" class="input-flex">
                                <span>EAP Auth Code</span>
                                <input type="text" id="authcode" placeholder="Authcode" />
                            </div>
                        </div>
                        <div id="Vld" class="validation"></div>
                        <div class="textarea" id="textareaBlock">
                            <div class="head">
                                <span>Referral Information</span>
                                <div class="text-right">
                                    <p id="showcount">Characters left: <span id="charCount">1423</span>
                                        <span>/1423</span>
                                    </p>
                                    <p class="err-msg">More than 160 character will be sent as 2 or more messages</p>
                                </div>
                            </div>
                            <div id="textarea-parent" class="textarea-parent">
                                <textarea id="referral-text" pattern=".{9}" placeholder="Referral Information"></textarea>
                                <!-- <span class="placeholder">
                                                    Referral Information
                                                </span> -->
                            </div>
                        </div>
                        <div class="btn-container">
                            <div class="button-right">
                                <button id="send-button" type="button" class="button">SEND</button>
                            </div>
                            <div class="button-right btn-margin">
                                <button id="preview-button" type="button" class="button">PREVIEW</button>
                            </div>
                        </div>
                    </form>
                </div>
                <footer>
                    <div class="logo">
                        <img src="./images/evn_logo_HS_SM_rgb_tempermint.svg" alt="Cigna Logo">
                    </div>
                    <div class="copyrights">
                        © 2023 Evernorth. All rights reserved. All products and services are provided by or through
                        operating subsidiaries or affiliates of Evernorth.
                    </div>
                </footer>
                <div id="mask"></div>
                <div id="status"></div>
                <div id="loader"><img src="./images/loader.gif" /></div>
                <div id="preview" class="popup">
                    <div class="close">
                        <div class="padder">Message Preview</div>
                        <svg class="close-button" id="close-button" viewBox="0 0 24 24" fill="none"
                            xmlns="http://www.w3.org/2000/svg">
                            <path d="M5 5L19 19M5 19L19 5" stroke="#FFFFFF" stroke-width="2" stroke-linecap="round"
                                stroke-linejoin="round" />
                        </svg>
                    </div>
                    <div id="popup-content"></div>
                    <div class="footer">
                        <div id="copy-button" class="copy">
                            <svg id="copy-icon" width="40px" height="40px" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <g clip-path="url(#a)">
                                    <path fill-rule="evenodd" clip-rule="evenodd"
                                        d="M8 5h7.795c1.115 0 1.519.116 1.926.334.407.218.727.538.945.945.218.407.334.811.334 1.926V16a1 1 0 1 0 2 0V8.128c0-1.783-.186-2.43-.534-3.082a3.635 3.635 0 0 0-1.512-1.512C18.302 3.186 17.655 3 15.872 3H8a1 1 0 0 0 0 2zm7.721 2.334C15.314 7.116 14.91 7 13.795 7h-7.59c-1.115 0-1.519.116-1.926.334a2.272 2.272 0 0 0-.945.945C3.116 8.686 3 9.09 3 10.205v7.59c0 1.114.116 1.519.334 1.926.218.407.538.727.945.945.407.218.811.334 1.926.334h7.59c1.114 0 1.519-.116 1.926-.334.407-.218.727-.538.945-.945.218-.407.334-.811.334-1.926v-7.59c0-1.115-.116-1.519-.334-1.926a2.272 2.272 0 0 0-.945-.945z"
                                        fill="#034740" />
                                </g>
                                <defs>
                                    <clipPath id="a">
                                        <path fill="#034740" d="M0 0h24v24H0z" />
                                    </clipPath>
                                </defs>
                            </svg>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </body>
    
    </html>`)
});

module.exports = router;