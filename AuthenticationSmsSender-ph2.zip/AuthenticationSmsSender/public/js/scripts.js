
const maxCharacters = 1423;
function onload() {
    const textarea = document.getElementById('referral-text');
    const placeholder = document.querySelector('.placeholder');
    const charCountElement = document.getElementById('charCount');


    const eapCheck = document.querySelector("#EAP");
    const providerReferrals = document.querySelector("#providerReferrals");
    const textareaBlock = document.querySelector("#textareaBlock");
    const textingTemplates = document.querySelector("#textingTemplates");
    const templateBlock = document.querySelector("#template-ctr");
    const templateSelector = document.querySelector("#templates");
    textareaBlock.style.display = "none";


    var phoneInput = document.getElementById('phone');
    var sendButton = document.getElementById('send-button');
    var authCode = document.getElementById('authcode');
    var previewButton = document.getElementById('preview-button');
    var authCtr = document.getElementById('auth-ctr');

    var popupClose = document.getElementById('close-button');
    var previewPopup = document.getElementById('preview');
    var popupContent = document.getElementById('popup-content');
    var mask = document.getElementById('mask');
    var copyButton = document.getElementById('copy-button');
    var copyIcon = document.getElementById('copy-icon');
    var textParent = document.getElementById('textarea-parent');
    var Vld = document.getElementById('Vld');
    var status = document.getElementById('status');
    var loader = document.getElementById('loader');
    const customerFirstName = document.querySelector("#t0-CustomerFirstName");
    const agentName = document.querySelector("#t0-AgentName");
    const refLink = document.querySelector("#t1-refLink");


    const brandCigna = document.querySelector("#brandCigna");
    const brandEverNorth = document.querySelector("#brandEverNorth");

    // t2
    const t2Name = document.querySelector("#t2-Name");
    const t2Address = document.querySelector("#t2-address");
    const t2ProviderPhone = document.querySelector("#t2-provider-phone");
    const t2AgentPhone = document.querySelector("#t2-agent-phone");
    const t2Ext = document.querySelector("#t2-Ext");
    const t2Comments = document.querySelector("#t2-comment");

    t2Name.addEventListener('change', () => {
        t2Name.style.borderColor = '#cbcaca';
    });

    t2Address.addEventListener('change', () => {
        t2Address.style.borderColor = '#cbcaca';
    });
    t2ProviderPhone.addEventListener('input', (e) => {
        var x = e.target.value.replace(/\D/g, '').match(/(\d{0,3})(\d{0,3})(\d{0,4})/);
        e.target.value = !x[2] ? x[1] : '(' + x[1] + ') ' + x[2] + (x[3] ? '-' + x[3] : '');
        t2ProviderPhone.style.borderColor = '#cbcaca';
    });
    t2AgentPhone.addEventListener('input', (e) => {
        var x = e.target.value.replace(/\D/g, '').match(/(\d{0,3})(\d{0,3})(\d{0,4})/);
        e.target.value = !x[2] ? x[1] : '(' + x[1] + ') ' + x[2] + (x[3] ? '-' + x[3] : '');
        t2AgentPhone.style.borderColor = '#cbcaca';
    });
    t2Ext.addEventListener('change', () => {
        t2Ext.style.borderColor = '#cbcaca';
    });

    // t3

    const t3CustomerFirstName = document.querySelector("#t3-customer-first-Name");
    const t3AgentName = document.querySelector("#t3-agent-Name");
    const t3AgentPhone = document.querySelector("#t3-agent-phone");
    const t3Ext = document.querySelector("#t3-Ext");
    const t3Type = document.querySelector("#t3-type");

    t3CustomerFirstName.addEventListener('change', () => {
        t3CustomerFirstName.style.borderColor = '#cbcaca';
    });

    t3Type.addEventListener('change', () => {
        t3Type.style.borderColor = '#cbcaca';
    });

    t3AgentName.addEventListener('change', () => {
        t3AgentName.style.borderColor = '#cbcaca';
    });

    t3AgentPhone.addEventListener('input', (e) => {
        var x = e.target.value.replace(/\D/g, '').match(/(\d{0,3})(\d{0,3})(\d{0,4})/);
        e.target.value = !x[2] ? x[1] : '(' + x[1] + ') ' + x[2] + (x[3] ? '-' + x[3] : '');
        t3AgentPhone.style.borderColor = '#cbcaca';
    });
    t3Ext.addEventListener('change', () => {
        t3Ext.style.borderColor = '#cbcaca';
    });

    // t4

    const t4CustomerFirstName = document.querySelector("#t4-customer-first-Name");
    const t4AgentName = document.querySelector("#t4-agent-Name");
    const t4AppointmentDate = document.querySelector("#t4-appointment-date");
    const t4Hr = document.querySelector("#t4-hr");
    const t4Min = document.querySelector("#t4-min");
    const t4Am = document.querySelector("#t4-am");
    const t4AgentPhone = document.querySelector("#t4-agent-phone");

    t4CustomerFirstName.addEventListener('change', () => {
        t4CustomerFirstName.style.borderColor = '#cbcaca';
    });

    t4AgentName.addEventListener('change', () => {
        t4AgentName.style.borderColor = '#cbcaca';
    });

    t4AppointmentDate.addEventListener('change', () => {
        t4AppointmentDate.style.borderColor = '#cbcaca';
    });

    t4Hr.addEventListener('change', () => {
        t4Hr.style.borderColor = '#cbcaca';
    });

    t4Min.addEventListener('change', () => {
        t4Min.style.borderColor = '#cbcaca';
    });

    t4Am.addEventListener('change', () => {
        t4Am.style.borderColor = '#cbcaca';
    });

    t4AgentPhone.addEventListener('input', (e) => {
        var x = e.target.value.replace(/\D/g, '').match(/(\d{0,3})(\d{0,3})(\d{0,4})/);
        e.target.value = !x[2] ? x[1] : '(' + x[1] + ') ' + x[2] + (x[3] ? '-' + x[3] : '');
        t4AgentPhone.style.borderColor = '#cbcaca';
    });


    const htmlDecoder = (str) => {
        var div = document.createElement('div');
        div.innerHTML = str;
        var htmlDecoded = div.firstChild.nodeValue;
        return htmlDecoded;
    }

    textarea.addEventListener('input', () => {
        const currentCharacters = textarea.value.length;
        const remainingCharacters = maxCharacters - currentCharacters;

        charCountElement.textContent = remainingCharacters;

        if (remainingCharacters >= 0) {
            charCountElement.style.color = 'inherit';
        } else {
            charCountElement.style.color = 'red';
        }
        textarea.style.borderColor = '#cbcaca';

        // Prevent input beyond the character limit
        if (currentCharacters > maxCharacters) {
            //textarea.value = textarea.value.substring(0, maxCharacters);
        }
    });

    providerReferrals.addEventListener("change", function () {
        textareaBlock.style.display = "flex";
        authCtr.style.display = "none";
        templateBlock.style.display = "none";
    });

    eapCheck.addEventListener('change', () => {
        textareaBlock.style.display = "none";
        authCtr.style.display = 'flex';
        templateBlock.style.display = "none";
    });

    textingTemplates.addEventListener('click', () => {
        textareaBlock.style.display = "none";
        authCtr.style.display = "none";
        templateBlock.style.display = "flex";
    });


    popupClose.addEventListener('click', () => {
        previewPopup.style.display = 'none';
        popupContent.innerHTML = '';
        mask.style.display = 'none';
    });

    copyButton.addEventListener('click', async () => {
        const content = htmlDecoder(popupContent.innerHTML.replace(/<br>/g, ''));
        await navigator.clipboard.writeText(content);
        copyIcon.style.boxShadow = '2px 2px grey';
        setTimeout(() => {
            copyIcon.style.boxShadow = 'none';
        }, 200);
    });

    templateSelector.addEventListener('change', (evt) => {
        templateSelector.style.borderColor = '#cbcaca';
        const selection = parseInt(evt.target.value);
        console.log(selection);

        for (let i = 0; i < 5; i++) {
            const template = document.querySelector(`#template${i}`);
            template.style.display = 'none';
        }

        if (selection < 0) {
            return;
        }
        const template = document.querySelector(`#template${selection}`);
        template.style.display = 'flex';
    });

    customerFirstName.addEventListener('change', () => {
        customerFirstName.style.borderColor = '#cbcaca';
    });

    agentName.addEventListener('change', () => {
        agentName.style.borderColor = '#cbcaca';
    });

    refLink.addEventListener('change', () => {
        refLink.style.borderColor = '#cbcaca';
    });

    const getTemplate0Message = () => {
        return `Hi ${customerFirstName.value.trim()}, it’s ${agentName.value.trim()}, from ${brandCigna.checked ? 'Cigna' : 'Evernorth'}. Do you agree to receive texts from ${brandCigna.checked ? 'Cigna' : 'Evernorth'}, its agent partners and affiliates at this number? Message and data rates may apply. Respond "Y" for Yes or "N" for No.`;
    }

    const getTemplate1Message = () => {
        return `Here is a link to EBCG (or Alma/MDLIVE) ${refLink.value.trim()} where you can schedule your appointment online. Questions? Call the number on the back of your ID card. Reply STOP to opt out.`
    }

    const getTemplate2Message = () => {
        return `Here is the information for the provider. ${t2Name.value.trim()}, ${t2Address.value.trim()}, +1${t2ProviderPhone.value.trim().replace(/^\+1/,'')}. Questions? Call me at +1${t2AgentPhone.value.trim().replace(/^\+1/,'')} ext ${t2Ext.value.trim()}. ${t2Comments.value ? `${t2Comments.value.trim()}.`: ''} Reply STOP to opt out.`;
    }

    const getTemplate3Message = () => {
        return `Hi ${t3CustomerFirstName.value.trim()}, it’s ${t3AgentName.value.trim()}, from ${brandCigna.checked ? 'Cigna' : 'Evernorth'}. Were you able to connect to your ${t3Type.value}? Respond “Y” for Yes or “N” for No. Questions? Call me at +1${t3AgentPhone.value.trim().replace(/^\+1/,'')} ext ${t3Ext.value.trim()}. Reply STOP to opt out.`;
    }

    const getTime = () => {
        return `${t4Hr.value}:${t4Min.value} ${t4Am.value}`
    }

    const getTemplate4Message = () => {
        return `Hi ${t4CustomerFirstName.value.trim()} it’s ${t4AgentName.value.trim()}, from ${brandCigna.checked ? 'Cigna' : 'Evernorth'}, reaching out to confirm your call with me on (${dayjs(t4AppointmentDate.value.trim()).format('MM/DD/YYYY')} @ ${getTime()}). Reply “Y” for Yes or “N” for No. To reschedule call ${t4AgentPhone.value.trim()}. Reply STOP to opt out.`
    }


    previewButton.addEventListener('click', () => {
        var isBrandCignaSelected = brandCigna.checked ? true : false;
        var isBrandEverNorthSelected = brandEverNorth.checked ? true : false;
        const authCodeText = authCode.value?.trim();
        const providerReferralText = providerReferrals.checked ? textarea.value.trim().replace(/\n/g, '<br>') : "";
        const refrralLink = refLink.value.trim();
        var disclosureAndQuestions = "<br>Questions? Call the number on the back of your ID card. <br>Click for disclosures:";
        if (isBrandCignaSelected)
            disclosureAndQuestions += "txt.hcpdirectory.cigna.com/t3eR9Tj2oP";

        else if (isBrandEverNorthSelected)
            disclosureAndQuestions += "txt.well.evernorth.com/t3eR9Tj2oP";
        if (eapCheck.checked) {
            popupContent.innerHTML = `Here is your code: ${authCodeText}. ${disclosureAndQuestions}`;
        }
        else if (providerReferrals.checked) {
            popupContent.innerHTML = `Here are your providers: <br> ${providerReferralText} ${disclosureAndQuestions}`;
        }
        else {
            const templateSelection = parseInt(templateSelector.value);
            if (templateSelection < 0) {
                Vld.innerHTML = "Select template";
                return;
            }

            if (templateSelection === 0) {
                popupContent.innerHTML = getTemplate0Message();
            }

            if (templateSelection === 1) {
                popupContent.innerHTML = getTemplate1Message();
            }

            if (templateSelection === 2) {
                popupContent.innerHTML = getTemplate2Message();
            }

            if (templateSelection === 3) {
                popupContent.innerHTML = getTemplate3Message();
            }

            
            if (templateSelection === 4) {
                popupContent.innerHTML = getTemplate4Message();
            }
            
        }
        previewPopup.style.display = 'flex';
        mask.style.display = 'block';
    });

    phoneInput.addEventListener('input', function (e) {
        var x = e.target.value.replace(/\D/g, '').match(/(\d{0,3})(\d{0,3})(\d{0,4})/);
        e.target.value = !x[2] ? x[1] : '(' + x[1] + ') ' + x[2] + (x[3] ? '-' + x[3] : '');
        phoneInput.style.borderColor = '#cbcaca';
    });

    authCode.addEventListener('input', function (e) {
        authCode.style.borderColor = '#cbcaca';
    });

    function stripHtmlTags(str) {
        let tempDiv = document.createElement("div");
        tempDiv.innerHTML = str;
        return tempDiv.textContent || tempDiv.innerText || "";
    }


    sendButton.addEventListener('click', async function (e) {
        try {
            let templateText = '';
            const phone = phoneInput.value.replace(/\D/g, '');
            var isBrandCignaSelected = brandCigna.checked ? true : false;
            var isBrandEverNorthSelected = brandEverNorth.checked ? true : false;
            const authCodeText = authCode.value?.trim();
            const templateSelection = parseInt(templateSelector.value);
            const providerReferralText = providerReferrals.checked ? textarea.value.trim().replace(/\n/g, '<br>') : "";

            const cName = customerFirstName.value.trim();
            const aName = agentName.value.trim();
            const refrralLink = refLink.value.trim();

            let validationErrors = false;
            let validationErrorsString = '';
            if (!phone) {
                validationErrors = true;
                phoneInput.style.borderColor = 'red';
                validationErrorsString += "*Phone number required. "
            }

            if (eapCheck.checked && !authCodeText) {
                validationErrors = true;
                authCode.style.borderColor = 'red';
                validationErrorsString += '* Authorization code required. ';
            }

            if (providerReferrals.checked && !providerReferralText) {
                validationErrors = true;
                textParent.style.borderColor = 'red';
                validationErrorsString += '* Referral information required. ';
            }

            if (providerReferrals.checked && providerReferralText && providerReferralText.length > 1423) {
                validationErrors = true;
                textParent.style.borderColor = 'red';
                validationErrorsString += '* Referral information cannot be more then 1423 characters.';
            }

            if (textingTemplates.checked) {
                if (templateSelection < 0) {
                    validationErrors = true;
                    templateSelector.style.borderColor = 'red';
                    validationErrorsString += "Template not selected. ";
                }

                if (templateSelection === 0) {
                    if (!cName) {
                        customerFirstName.style.borderColor = 'red';
                        validationErrors = true;
                        validationErrorsString += "Customer first name empty. ";
                    }
                    if (!aName) {
                        agentName.style.borderColor = 'red';
                        validationErrors = true;
                        validationErrorsString += "Agent name empty. ";
                    }
                }

                if (templateSelection === 1 && !refrralLink) {
                    refLink.style.borderColor = 'red';
                    validationErrors = true;
                    validationErrorsString += "Refrral link is empty. ";
                }

                if (templateSelection === 2){
                    if (!t2Name.value) {
                        t2Name.style.borderColor = 'red';
                        validationErrors = true;
                        validationErrorsString += "Provider name is empty. ";
                    }

                    if (!t2Address.value) {
                        t2Address.style.borderColor = 'red';
                        validationErrors = true;
                        validationErrorsString += "Provider address is empty. ";
                    }

                    if (!t2ProviderPhone.value) {
                        t2ProviderPhone.style.borderColor = 'red';
                        validationErrors = true;
                        validationErrorsString += "Provider phone is empty. ";
                    }

                    if (!t2AgentPhone.value) {
                        t2AgentPhone.style.borderColor = 'red';
                        validationErrors = true;
                        validationErrorsString += "Agent phone is empty. ";
                    }

                    if (!t2Ext.value) {
                        t2Ext.style.borderColor = 'red';
                        validationErrors = true;
                        validationErrorsString += "Agent extension is empty. ";
                    }
                }

                if (templateSelection === 3) {
                    if (!t3CustomerFirstName.value) {
                        t3CustomerFirstName.style.borderColor = 'red';
                        validationErrors = true;
                        validationErrorsString += "Customer first name is empty. ";
                    }

                    if (!t3AgentName.value) {
                        t3AgentName.style.borderColor = 'red';
                        validationErrors = true;
                        validationErrorsString += "Agent name is empty. ";
                    }

                    if (!t3AgentPhone.value) {
                        t3AgentPhone.style.borderColor = 'red';
                        validationErrors = true;
                        validationErrorsString += "Agent phone number is empty. ";
                    }

                    
                    if (!t3Ext.value) {
                        t3Ext.style.borderColor = 'red';
                        validationErrors = true;
                        validationErrorsString += "Agent phone ext is empty. ";
                    }
                }

                if (templateSelection === 4) {
                    if (!t4CustomerFirstName.value) {
                        t4CustomerFirstName.style.borderColor = 'red';
                        validationErrors = true;
                        validationErrorsString += "Customer first name is empty. ";
                    }

                    if (!t4AgentName.value) {
                        t4AgentName.style.borderColor = 'red';
                        validationErrors = true;
                        validationErrorsString += "Customer first name is empty. ";
                    }

                    
                    if (!t4AppointmentDate.value) {
                        t4AppointmentDate.style.borderColor = 'red';
                        validationErrors = true;
                        validationErrorsString += "Customer first name is empty. ";
                    }

                    if (!t4Hr.value) {
                        t4Hr.style.borderColor = 'red';
                        validationErrors = true;
                        validationErrorsString += "Customer first name is empty. ";
                    }

                    if (!t4Min.value) {
                        t4Min.style.borderColor = 'red';
                        validationErrors = true;
                        validationErrorsString += "Customer first name is empty. ";
                    }

                    if (!t4Am.value) {
                        t4Am.style.borderColor = 'red';
                        validationErrors = true;
                        validationErrorsString += "Customer first name is empty. ";
                    }

                    
                    if (!t4AgentPhone.value) {
                        t4AgentPhone.style.borderColor = 'red';
                        validationErrors = true;
                        validationErrorsString += "Customer first name is empty. ";
                    }
                }
            }


            if (validationErrors) {
                Vld.innerHTML = `Validation Errors: ${validationErrorsString}`;
            }

            if (!validationErrors) {
                var disclosureAndQuestions = "<br>Questions? Call the number on the back of your ID card. <br>Click for disclosures:";
                if (isBrandCignaSelected)
                    disclosureAndQuestions += "txt.hcpdirectory.cigna.com/t3eR9Tj2oP";

                else if (isBrandEverNorthSelected)
                    disclosureAndQuestions += "txt.well.evernorth.com/t3eR9Tj2oP";
                if (eapCheck.checked) {
                    templateText = `Here is your code: ${authCodeText}. ${disclosureAndQuestions}`;
                }
                else if (providerReferrals.checked) {
                    templateText = `Here are your providers: <br> ${providerReferralText} ${disclosureAndQuestions}`;
                }
                else {
                    if (templateSelection === 0) {
                        templateText = getTemplate0Message();
                    }

                    if (templateSelection === 1) {
                        templateText = getTemplate1Message();
                    }

                    if (templateSelection === 2) {
                        templateText = getTemplate2Message();
                    }

                    if (templateSelection === 3) {
                        templateText = getTemplate3Message();
                    }

                    
                    if (templateSelection === 4) {
                        templateText = getTemplate4Message();
                    }
                }
                loader.style.display = 'block';
                phoneInput.style.borderColor = '#cbcaca';
                authCode.style.borderColor = '#cbcaca';
                textParent.style.borderColor = '#cbcaca';
                const resp = await fetch("/sendMessage", {
                    method: "POST", // *GET, POST, PUT, DELETE, etc.
                    mode: "cors", // no-cors, *cors, same-origin
                    cache: "no-cache", // *default, no-cache, reload, force-cache, only-if-cached
                    credentials: "same-origin", // include, *same-origin, omit
                    headers: {
                        "Content-Type": "application/json",
                        // 'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    redirect: "follow", // manual, *follow, error
                    referrerPolicy: "no-referrer", // no-referrer, *no-referrer-when-downgrade, origin, origin-when-cross-origin, same-origin, strict-origin, strict-origin-when-cross-origin, unsafe-url
                    body: JSON.stringify({
                        phone,
                        data: {
                            templateText: stripHtmlTags(templateText)
                        }
                    }), // body data type must match "Content-Type" header
                });

                if (resp.ok) {
                    phoneInput.value = '';
                    authCode.value = '';
                    textarea.value = '';
                    customerFirstName.value = '';
                    agentName.value = '';
                    refLink.value = '';
                    t2Name.value = '';
                    t2Address.value = '';
                    t2AgentPhone.value = '';
                    t2Comments.value = '';
                    t2Ext.value = '';
                    t2ProviderPhone.value = '';
                    t3AgentName.value = '';
                    t3AgentPhone.value = '';
                    t3CustomerFirstName.value ='';
                    t3Ext.value ='';
                    t4AgentName.value = '';
                    t4AgentPhone.value = '';
                    t4CustomerFirstName.value ='';
                    t4AppointmentDate.value = '';
                    showStatus(false);
                }
                else {
                    showStatus(true);
                }

                Vld.innerHTML = '';
            }
            e.preventDefault(); // You wouldn't prevent it
        } catch (ex) {
            console.error(ex);
            showStatus(true);
        }
        finally {
            loader.style.display = 'none';
        }
    });

    const showStatus = (isError) => {
        status.style.display = 'flex';
        status.style.color = isError ? 'Red' : 'Green';
        status.innerHTML = isError ? 'Something went wrong.' : 'Text message sent successfully.';
        setTimeout(() => {
            status.style.display = 'none';
        }, 1800);
    };


}









