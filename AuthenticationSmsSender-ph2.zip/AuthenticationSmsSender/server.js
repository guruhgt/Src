const express = require('express');
const mainRouter = require('./src/controllers');
const bodyParser = require('body-parser');

require('dotenv').config();
  
const app = express();
const PORT = process.env.PORT;

app.use(bodyParser.json());

app.use(express.static('public'));

app.use(mainRouter);


app.listen(PORT, (error) =>{
    if(!error)
        console.log("Server is Successfully Running, and App is listening on port "+ PORT)
    else 
        console.log("Error occurred, server can't start", error);
    }
);