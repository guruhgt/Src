const router = require('express').Router();

router.get("/", (_, res) => {
    res.send(`<!DOCTYPE html>
<html>

<head>
    <title>CIGNA</title>
    <link rel="stylesheet" href="./fonts/font.css" />
    <link rel="stylesheet" href="./css/styles.css" />
    <script src="https://cdn.jsdelivr.net/npm/dayjs@1/dayjs.min.js"></script>
    <script src="./js/scripts.js"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>


<body onload="onload()">

    <div class="main-wrapper">
        <div class="wrapper">
            <header>
                <div class="logo">
                    <img src="./images/cigna-logo.png" alt="Cigna Logo">
                </div>
                <div class="title">
                    <b>EVERNORTH</b> OUTBOUND TEXTING
                </div>
            </header>
            <div class="content-wrapper">
                <h2>Customer Information</h2>
                <form id="myForm">
                    <div class="form-header">
                        <div class="input-flex">
                            <span>Phone Number</span>
                            <div class="number-input">
                                <span class="country-code">+1</span>
                                <input type="text" id="phone" placeholder="(123) 456-5555" />
                            </div>
                        </div>
                        <div class="input-flex checkbox">
                            <label class="checkbox-flex">
                                <input type="radio" name="choice" id="EAP" checked />
                                <span class="checkmark"></span>
                                <span>EAP Auth Code</span>
                            </label>
                            <label class="checkbox-flex">
                                <input type="radio" name="choice" id="providerReferrals" />
                                <span class="checkmark"></span>
                                <span>Provider Referrals</span>
                            </label>
                            <label class="checkbox-flex">
                                <input type="radio" name="choice" id="textingTemplates" />
                                <span class="checkmark"></span>
                                <span>Texting templates</span>
                            </label>
                        </div>
                        <div id="auth-ctr" class="input-flex">
                            <span>EAP Auth Code</span>
                            <input type="text" id="authcode" placeholder="Authcode" />
                        </div>
                        <div id="template-ctr">
                            <div class="selection-ctr">
                                <div class="input-flex">
                                    <label for="templates">Select template:</label>
                                    <div class="number-input">
                                        <select id="templates" placeholder="">
                                            <option value="-1"> </option>
                                            <option value="0">Consent text</option>
                                            <option value="1">Virtual Provider Referral (SAS)</option>
                                            <option value="2">In-Person Provider/Facility Referral</option>
                                            <option value="3">Confirm Connect to Care</option>
                                            <option value="4">Appointment Confirmation</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="details">
                                <div id="template0">
                                    <h3 class="header3">Consent Text</h3>
                                    <div class="selection-ctr">
                                        <div class="input-flex">
                                            <span>First Name</span>
                                            <input type="text" id="t0-CustomerFirstName"
                                                placeholder="Customer first name" />
                                        </div>
                                    </div>
                                    <div class="selection-ctr">
                                        <div class="input-flex">
                                            <span>Agent Name</span>
                                            <input type="text" id="t0-AgentName" placeholder="Agent name" />
                                        </div>
                                    </div>
                                </div>
                                <div id="template1">
                                    <h3 class="header3">Virtual Provider Referral (SAS)</h3>
                                    <div class="selection-ctr">
                                        <div class="input-flex">
                                            <span>EBCG or Alma/MDLIVE</span>
                                            <input type="text" id="t1-refLink" placeholder="Referral link" />
                                        </div>
                                    </div>
                                </div>
                                <div id="template2">
                                    <h3 class="header3">In-Person Provider/Facility Referral</h3>
                                    <div class="grid">
                                        <div class="input-label"><div class="inner-text">Name: </div></div>
                                        <div>
                                            <input type="text" id="t2-Name"
                                            class="inpt"
                                                placeholder="" />
                                        </div>
                                        <div class="input-label"><div class="inner-text">Address: </div></div>
                                        <div>
                                            <textarea class="text-area-ctr" id="t2-address" pattern=".{9}"></textarea>
                                        </div>
                                        <div class="input-label"><div class="inner-text">Provider Phone: </div></div>
                                        <div class="phone-ctr">
                                            <span class="country-code">+1</span>
                                            <input type="text" class="inpt" id="t2-provider-phone" placeholder="(123) 456-5555" />
                                        </div>
                                        <div class="input-label"><div class="inner-text">Agent Phone: </div></div>
                                        <div class="phone-ctr">
                                            <span class="country-code">+1</span>
                                            <input type="text" class="inpt" id="t2-agent-phone" placeholder="(123) 456-5555" />
                                        </div>
                                        <div class="input-label"><div class="inner-text">Ext: </div></div>
                                        <div>
                                            <input type="text" id="t2-Ext"
                                            class="inpt"
                                                placeholder="" />
                                        </div>
                                        <div class="input-label"><div class="inner-text">Comments: </div></div>
                                        <div>
                                            <textarea class="text-area-ctr" id="t2-comment" pattern=".{9}"></textarea>
                                        </div>
                                    </div>
                                </div>
                                <div id="template3">
                                    <h3 class="header3">Confirm Connect to Care</h3>
                                    <div class="grid">
                                        <div class="input-label"><div class="inner-text">Customer First Name: </div></div>
                                        <div>
                                            <input type="text" id="t3-customer-first-Name"
                                            class="inpt"
                                                placeholder="" />
                                        </div>
                                        <div class="input-label"><div class="inner-text">Agent Name: </div></div>
                                        <div>
                                            <input type="text" id="t3-agent-Name"
                                            class="inpt"
                                                placeholder="" />
                                        </div>
                                        <div class="input-label"><div class="inner-text">Agent Phone: </div></div>
                                        <div class="phone-ctr">
                                            <span class="country-code">+1</span>
                                            <input type="text" class="inpt" id="t3-agent-phone" placeholder="(123) 456-5555" />
                                        </div>
                                        <div class="input-label"><div class="inner-text">Ext: </div></div>
                                        <div>
                                            <input type="text" id="t3-Ext"
                                            class="inpt"
                                                placeholder="" />
                                        </div>
                                        <div class="input-label"><div class="inner-text">Type: </div></div>
                                        <div class="half">
                                            <select title="type" id="t3-type">
                                                <option value="provider">Provider</option>
                                                <option value="facility">Facility</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div id="template4">
                                    <h3 class="header3">Appointment Confirmation</h3>
                                    <div class="grid">
                                        <div class="input-label"><div class="inner-text">Customer First Name: </div></div>
                                        <div>
                                            <input type="text" id="t4-customer-first-Name"
                                            class="inpt"
                                                placeholder="" />
                                        </div>
                                        <div class="input-label"><div class="inner-text">Agent Name: </div></div>
                                        <div>
                                            <input type="text" id="t4-agent-Name"
                                            class="inpt"
                                                placeholder="" />
                                        </div>
                                        <div class="input-label"><div class="inner-text">Date: </div></div>
                                        <div>
                                            <input type="date" id="t4-appointment-date"
                                            class="inpt"
                                                placeholder="" />
                                        </div>
                                        <div class="input-label"><div class="inner-text">Time: </div></div>
                                        <div class="half">
                                            <div class="time">
                                                <select title="hr" id="t4-hr">
                                                    <option value="01">01</option>
                                                    <option value="02">02</option>
                                                    <option value="03">03</option>
                                                    <option value="04">04</option>
                                                    <option value="05">05</option>
                                                    <option value="06">06</option>
                                                    <option value="07">07</option>
                                                    <option value="08">08</option>
                                                    <option value="09">09</option>
                                                    <option value="10">10</option>
                                                    <option value="11">11</option>
                                                    <option value="12">12</option>
                                                </select>
                                                <div class="colon-ctr"><span class="inner-text">:</span></div>
                                                <select title="min" id="t4-min">
                                                    <option value="00">00</option>
                                                    <option value="01">01</option>
                                                    <option value="02">02</option>
                                                    <option value="03">03</option>
                                                    <option value="04">04</option>
                                                    <option value="05">05</option>
                                                    <option value="06">06</option>
                                                    <option value="07">07</option>
                                                    <option value="08">08</option>
                                                    <option value="09">09</option>
                                                    <option value="10">10</option>
                                                    <option value="11">11</option>
                                                    <option value="12">12</option>
                                                    <option value="13">13</option>
                                                    <option value="14">14</option>
                                                    <option value="15">15</option>
                                                    <option value="16">16</option>
                                                    <option value="17">17</option>
                                                    <option value="18">18</option>
                                                    <option value="19">19</option>
                                                    <option value="20">20</option>
                                                    <option value="21">21</option>
                                                    <option value="22">22</option>
                                                    <option value="23">23</option>
                                                    <option value="24">24</option>
                                                    <option value="25">25</option>
                                                    <option value="26">26</option>
                                                    <option value="27">27</option>
                                                    <option value="28">28</option>
                                                    <option value="29">29</option>
                                                    <option value="30">30</option>
                                                    <option value="31">31</option>
                                                    <option value="32">32</option>
                                                    <option value="33">33</option>
                                                    <option value="34">34</option>
                                                    <option value="35">35</option>
                                                    <option value="36">36</option>
                                                    <option value="37">37</option>
                                                    <option value="38">38</option>
                                                    <option value="39">39</option>
                                                    <option value="40">40</option>
                                                    <option value="41">41</option>
                                                    <option value="42">42</option>
                                                    <option value="43">43</option>
                                                    <option value="44">44</option>
                                                    <option value="45">45</option>
                                                    <option value="46">46</option>
                                                    <option value="47">47</option>
                                                    <option value="48">48</option>
                                                    <option value="49">49</option>
                                                    <option value="50">50</option>
                                                    <option value="51">51</option>
                                                    <option value="52">52</option>
                                                    <option value="53">53</option>
                                                    <option value="54">54</option>
                                                    <option value="55">55</option>
                                                    <option value="56">56</option>
                                                    <option value="57">57</option>
                                                    <option value="58">58</option>
                                                    <option value="59">59</option>
                                                </select>
                                                <div class="am">
                                                    <select title="am" id="t4-am">
                                                        <option value="AM">AM</option>
                                                        <option value="PM">PM</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="input-label"><div class="inner-text">Agent Phone: </div></div>
                                        <div class="phone-ctr">
                                            <span class="country-code">+1</span>
                                            <input type="text" class="inpt" id="t4-agent-phone" placeholder="(123) 456-5555" />
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div id="Vld" class="validation"></div>
                    <div class="textarea" id="textareaBlock">
                        <div class="head">
                            <span>Referral Information</span>
                            <div class="text-right">
                                <p id="showcount">Characters left: <span id="charCount">1423</span>
                                    <span>/1600</span>
                                </p>
                                <p class="err-msg">More than 160 character will be sent as 2 or more messages</p>
                            </div>
                        </div>
                        <div id="textarea-parent" class="textarea-parent">
                            <textarea id="referral-text" pattern=".{9}" placeholder="Referral Information"></textarea>
                            <!-- <span class="placeholder">
                                                    Referral Information
                                                </span> -->
                        </div>
                    </div>
                    <div class="form-header">
                        <span>Select Brand:&nbsp;</span>
                        <div class="input-flex checkbox">
                            <label class="checkbox-flex">
                                <input type="radio" name="brand" id="brandCigna" checked />
                                <span class="checkmark"></span>
                                <span class="small-fontlabel">Cigna</span>
                            </label>
                            <label class="checkbox-flex">
                                <input type="radio" name="brand" id="brandEverNorth" />
                                <span class="checkmark"></span>
                                <span class="small-fontlabel">EverNorth</span>
                            </label>
                        </div>
                    </div>
                    <div class="btn-container">
                        <div class="button-right">
                            <button id="send-button" type="button" class="button">SEND</button>
                        </div>
                        <div class="button-right btn-margin">
                            <button id="preview-button" type="button" class="button">PREVIEW</button>
                        </div>
                    </div>
                </form>
            </div>
            <footer>
                <div class="logo">
                    <img src="./images/evn_logo_HS_SM_rgb_tempermint.svg" alt="Cigna Logo">
                </div>
                <div class="copyrights">
                    © 2023 Evernorth. All rights reserved. All products and services are provided by or through
                    operating subsidiaries or affiliates of Evernorth.
                </div>
            </footer>
            <div id="mask"></div>
            <div id="status"></div>
            <div id="loader"><img src="./images/loader.gif" /></div>
            <div id="preview" class="popup">
                <div class="close">
                    <div class="padder">Message Preview</div>
                    <svg class="close-button" id="close-button" viewBox="0 0 24 24" fill="none"
                        xmlns="http://www.w3.org/2000/svg">
                        <path d="M5 5L19 19M5 19L19 5" stroke="#FFFFFF" stroke-width="2" stroke-linecap="round"
                            stroke-linejoin="round" />
                    </svg>
                </div>
                <div id="popup-content"></div>
                <div class="footer">
                    <div id="copy-button" class="copy">
                        <svg id="copy-icon" width="40px" height="40px" viewBox="0 0 24 24" fill="none"
                            xmlns="http://www.w3.org/2000/svg">
                            <g clip-path="url(#a)">
                                <path fill-rule="evenodd" clip-rule="evenodd"
                                    d="M8 5h7.795c1.115 0 1.519.116 1.926.334.407.218.727.538.945.945.218.407.334.811.334 1.926V16a1 1 0 1 0 2 0V8.128c0-1.783-.186-2.43-.534-3.082a3.635 3.635 0 0 0-1.512-1.512C18.302 3.186 17.655 3 15.872 3H8a1 1 0 0 0 0 2zm7.721 2.334C15.314 7.116 14.91 7 13.795 7h-7.59c-1.115 0-1.519.116-1.926.334a2.272 2.272 0 0 0-.945.945C3.116 8.686 3 9.09 3 10.205v7.59c0 1.114.116 1.519.334 1.926.218.407.538.727.945.945.407.218.811.334 1.926.334h7.59c1.114 0 1.519-.116 1.926-.334.407-.218.727-.538.945-.945.218-.407.334-.811.334-1.926v-7.59c0-1.115-.116-1.519-.334-1.926a2.272 2.272 0 0 0-.945-.945z"
                                    fill="#034740" />
                            </g>
                            <defs>
                                <clipPath id="a">
                                    <path fill="#034740" d="M0 0h24v24H0z" />
                                </clipPath>
                            </defs>
                        </svg>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

</html>`)
});

module.exports = router;