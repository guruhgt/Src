const router = require('express').Router();
const createClient = require('twilio');

router.post('/sendMessage', (req, res) => {
  try {

    const client = createClient(process.env.accountSid, process.env.authToken);
    const {
      phone,
      data: {
        templateText
      } } = req.body;

    if (!templateText) throw "Auth code, provider referal text and template texts are empty."

    client.messages
      .create({
        body: templateText,
        from: process.env.phoneNo,
        to: phone
      })
      .then(message => {
        const { sid } = message;
        res.send(sid);
      }).catch(error => {
        res.status(400);
        res.json(error);
      });
  } catch (ex) {
    res.status(400);
    res.json(ex);
  }
});

const getMessageBody = (authCode, providerReferralText) => {
  const disclosureAndQuestions = `Questions? Call the number on the back of your ID card. Click for disclosures: txt.hcpdirectory.cigna.com/t3eR9Tj2oP & txt.well.evernorth.com/t3eR9Tj2oP`;
  if (!authCode && !providerReferralText) throw new Error("Invalid authcode and text");
  if (authCode && !providerReferralText) {
    return `Here is your code: ${authCode}.\n${disclosureAndQuestions}`;
  }

  if (!authCode && providerReferralText) {
    return `Here are your providers: ${providerReferralText}\n${disclosureAndQuestions}`;
  }

  return `Here is your code: ${authCode}. Here are your providers: ${providerReferralText} ${disclosureAndQuestions}`;
};


module.exports = router;