
const maxCharacters = 160;
function onload() {
    const textarea = document.getElementById('referral-text');
    const placeholder = document.querySelector('.placeholder');
    const charCountElement = document.getElementById('charCount');


    const eapCheck = document.querySelector("#EAP");
    const providerReferrals = document.querySelector("#providerReferrals");
    const textareaBlock = document.querySelector("#textareaBlock");
    textareaBlock.style.display = "none";

    textarea.addEventListener('input', () => {
        const currentCharacters = textarea.value.length;
        const remainingCharacters = maxCharacters - currentCharacters;

        charCountElement.textContent = remainingCharacters;

        if (remainingCharacters >= 0) {
            charCountElement.style.color = 'inherit';
        } else {
            charCountElement.style.color = 'red';
        }

        // Prevent input beyond the character limit
        if (currentCharacters > maxCharacters) {
            //textarea.value = textarea.value.substring(0, maxCharacters);
        }
    });

    providerReferrals.addEventListener("change", function () {
        textareaBlock.style.display =  providerReferrals.checked ? "flex" : "none";
    });


    var phoneInput = document.getElementById('phone');
    var sendButton = document.getElementById('send-button');
    var authCode = document.getElementById('authcode');
    var previewButton = document.getElementById('preview-button');

    var popupClose = document.getElementById('close-button');
    var previewPopup = document.getElementById('preview');
    var popupContent = document.getElementById('popup-content');
    var mask = document.getElementById('mask');
    var copyButton = document.getElementById('copy-button');
    var copyIcon = document.getElementById('copy-icon');


    popupClose.addEventListener('click', () => {
        previewPopup.style.display = 'none';
        popupContent.innerHTML = '';
        mask.style.display = 'none';
    });

    copyButton.addEventListener('click', async () => {
        await navigator.clipboard.writeText(popupContent.innerHTML);
        copyIcon.style.boxShadow = '2px 2px grey';
        setTimeout(() => {
            copyIcon.style.boxShadow = 'none';
        }, 200);
    });

   
    previewButton.addEventListener('click', () => {
        const authCodeText = authCode.value?.trim();
        const providerReferralText = providerReferrals.checked ? textarea.value.trim() : "";
        
        if (eapCheck.checked && !providerReferrals.checked) {
            popupContent.innerHTML = `Here is your code: ${authCodeText}.
            Questions? Call the number on the back of your ID card.
            Click for disclosures:
            Link1
            Link2`;
          }
        
        else if (!eapCheck.checked && providerReferrals.checked) {
            popupContent.innerHTML = `Here are your providers:
            ${providerReferralText}
            Questions? Call the number on the back of your ID card.
            Click for disclosures:
            Link1
            Link2`;
          }
          else {
            popupContent.innerHTML = `Here is your code: ${authCodeText}.
            Here are your providers:
            ${providerReferralText}
            Questions? Call the number on the back of your ID card.
            Click for disclosures:
            Link1
            Link2`;
          }
        previewPopup.style.display = 'flex';
        mask.style.display = 'block';
    });

    phoneInput.addEventListener('input', function (e) {
        var x = e.target.value.replace(/\D/g, '').match(/(\d{0,3})(\d{0,3})(\d{0,4})/);
        e.target.value = !x[2] ? x[1] : '(' + x[1] + ') ' + x[2] + (x[3] ? '-' + x[3] : '');
    });


    sendButton.addEventListener('click', async function (e) {
        try {
            sendButton.setAttribute('disabled', 'disabled');
            const phone = phoneInput.value.replace(/\D/g, '');
            const authCodeText = eapCheck.checked ? authCode.value?.trim() : "";
            const providerReferralText = providerReferrals.checked ? textarea.value.trim() : "";
    
            const response = await fetch("/sendMessage", {
                method: "POST", // *GET, POST, PUT, DELETE, etc.
                mode: "cors", // no-cors, *cors, same-origin
                cache: "no-cache", // *default, no-cache, reload, force-cache, only-if-cached
                credentials: "same-origin", // include, *same-origin, omit
                headers: {
                  "Content-Type": "application/json",
                  // 'Content-Type': 'application/x-www-form-urlencoded',
                },
                redirect: "follow", // manual, *follow, error
                referrerPolicy: "no-referrer", // no-referrer, *no-referrer-when-downgrade, origin, origin-when-cross-origin, same-origin, strict-origin, strict-origin-when-cross-origin, unsafe-url
                body: JSON.stringify({
                    phone,
                    data: {
                        authCodeText,
                        providerReferralText
                    }
                }), // body data type must match "Content-Type" header
              });
    
            e.preventDefault(); // You wouldn't prevent it
        } catch (ex) {

        }
        finally {
            sendButton.setAttribute('disabled', '');
        }
    });

    
}









