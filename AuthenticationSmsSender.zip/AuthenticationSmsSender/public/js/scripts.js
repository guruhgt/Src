
const maxCharacters = 1423;
function onload() {
    const textarea = document.getElementById('referral-text');
    const placeholder = document.querySelector('.placeholder');
    const charCountElement = document.getElementById('charCount');


    const eapCheck = document.querySelector("#EAP");
    const providerReferrals = document.querySelector("#providerReferrals");
    const textareaBlock = document.querySelector("#textareaBlock");
    textareaBlock.style.display = "none";

    
    var phoneInput = document.getElementById('phone');
    var sendButton = document.getElementById('send-button');
    var authCode = document.getElementById('authcode');
    var previewButton = document.getElementById('preview-button');
    var authCtr = document.getElementById('auth-ctr');

    var popupClose = document.getElementById('close-button');
    var previewPopup = document.getElementById('preview');
    var popupContent = document.getElementById('popup-content');
    var mask = document.getElementById('mask');
    var copyButton = document.getElementById('copy-button');
    var copyIcon = document.getElementById('copy-icon');
    var textParent = document.getElementById('textarea-parent');
    var Vld = document.getElementById('Vld');
    var status = document.getElementById('status');
    var loader = document.getElementById('loader');

    const htmlDecoder = (str) => {
        var div = document.createElement('div');
        div.innerHTML = str;
        var htmlDecoded = div.firstChild.nodeValue;
        return htmlDecoded;
    }

    textarea.addEventListener('input', () => {
        const currentCharacters = textarea.value.length;
        const remainingCharacters = maxCharacters - currentCharacters;

        charCountElement.textContent = remainingCharacters;

        if (remainingCharacters >= 0) {
            charCountElement.style.color = 'inherit';
        } else {
            charCountElement.style.color = 'red';
        }

        // Prevent input beyond the character limit
        if (currentCharacters > maxCharacters) {
            //textarea.value = textarea.value.substring(0, maxCharacters);
        }
    });

    providerReferrals.addEventListener("change", function () {
        textareaBlock.style.display =  "flex";
        authCtr.style.display = 'none';

    });

    eapCheck.addEventListener('change', () => {
        textareaBlock.style.display =  "none";
        authCtr.style.display = 'flex';
    });


    popupClose.addEventListener('click', () => {
        previewPopup.style.display = 'none';
        popupContent.innerHTML = '';
        mask.style.display = 'none';
    });

    copyButton.addEventListener('click', async () => {
        const content = htmlDecoder(popupContent.innerHTML.replace(/<br>/g, '')); 
        await navigator.clipboard.writeText(content);
        copyIcon.style.boxShadow = '2px 2px grey';
        setTimeout(() => {
            copyIcon.style.boxShadow = 'none';
        }, 200);
    });

   
    previewButton.addEventListener('click', () => {
        const authCodeText = authCode.value?.trim();
        const providerReferralText = providerReferrals.checked ? textarea.value.trim().replace(/\n/g, '<br>') : "";
        const disclosureAndQuestions = `<br>Questions? Call the number on the back of your ID card. <br>Click for disclosures: https://txt.hcpdirectory.cigna.com/t3eR9Tj2oP & https://txt.well.evernorth.com/t3eR9Tj2oP`;
        if (eapCheck.checked && !providerReferrals.checked) {
            popupContent.innerHTML = `Here is your code: ${authCodeText}. ${disclosureAndQuestions}`;
          }
        
        else if (!eapCheck.checked && providerReferrals.checked) {
            popupContent.innerHTML = `Here are your providers: <br> ${providerReferralText} ${disclosureAndQuestions}`;
          }
          else {
            popupContent.innerHTML = `Here is your code: ${authCodeText}.
            Here are your providers: ${providerReferralText} ${disclosureAndQuestions}`;
          }
        previewPopup.style.display = 'flex';
        mask.style.display = 'block';
    });

    phoneInput.addEventListener('input', function (e) {
        var x = e.target.value.replace(/\D/g, '').match(/(\d{0,3})(\d{0,3})(\d{0,4})/);
        e.target.value = !x[2] ? x[1] : '(' + x[1] + ') ' + x[2] + (x[3] ? '-' + x[3] : '');
    });


    sendButton.addEventListener('click', async function (e) {
        try {
            const phone = phoneInput.value.replace(/\D/g, '');
            const authCodeText = eapCheck.checked ? authCode.value?.trim() : "";
            const providerReferralText = providerReferrals.checked ? textarea.value.trim() : "";

            let validationErrors = false;
            let validationErrorsString = '';
            if (!phone) {
                validationErrors = true;
                phoneInput.style.borderColor = 'red';
                validationErrorsString += "*Phone number required. "
            }

            if (eapCheck.checked && !authCodeText) {
                validationErrors = true;
                authCode.style.borderColor = 'red';
                validationErrorsString += '* Authorization code required. ';
            }

            if (providerReferrals.checked && !providerReferralText) {
                validationErrors = true;
                textParent.style.borderColor = 'red';
                validationErrorsString += '* Referral information required. ';
            }

            if (providerReferrals.checked && providerReferralText && providerReferralText.length > 1423) {
                validationErrors = true;
                textParent.style.borderColor = 'red';
                validationErrorsString += '* Referral information cannot be more then 1423 characters.';
            }

            if (validationErrors) {
                Vld.innerHTML = `Validation Errors: ${validationErrorsString}`;
            }

            if (!validationErrors) {
                loader.style.display = 'block';
                phoneInput.style.borderColor = '#cbcaca';
                authCode.style.borderColor = '#cbcaca';
                textParent.style.borderColor = '#cbcaca';
                const resp = await fetch("/sendMessage", {
                    method: "POST", // *GET, POST, PUT, DELETE, etc.
                    mode: "cors", // no-cors, *cors, same-origin
                    cache: "no-cache", // *default, no-cache, reload, force-cache, only-if-cached
                    credentials: "same-origin", // include, *same-origin, omit
                    headers: {
                      "Content-Type": "application/json",
                      // 'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    redirect: "follow", // manual, *follow, error
                    referrerPolicy: "no-referrer", // no-referrer, *no-referrer-when-downgrade, origin, origin-when-cross-origin, same-origin, strict-origin, strict-origin-when-cross-origin, unsafe-url
                    body: JSON.stringify({
                        phone,
                        data: {
                            authCodeText,
                            providerReferralText
                        }
                    }), // body data type must match "Content-Type" header
                  });

                if (resp.ok) {
                    phoneInput.value = '';
                    authCode.value = '';
                    textarea.value = '';
                    showStatus(false);
                }
                else {
                    showStatus(true);
                }

                  Vld.innerHTML = '';
            }
            e.preventDefault(); // You wouldn't prevent it
        } catch (ex) {
            console.error(ex);
            showStatus(true);
        }
        finally {
            loader.style.display = 'none';
        }
    });

    const showStatus = (isError) => {
        status.style.display = 'flex';
        status.style.color = isError ? 'Red' : 'Green';
        status.innerHTML = isError ? 'Something went wrong.': 'Text message sent successfully.';
        setTimeout(() => {
            status.style.display = 'none';
        }, 1800);
    };

    
}









