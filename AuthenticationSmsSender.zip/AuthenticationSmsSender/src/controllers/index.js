var main = require("./main");
var messageHandler = require("./messageHandler");
var mainRouter = require('express').Router();

mainRouter.use(main);
mainRouter.use(messageHandler);

module.exports = mainRouter;