const router = require('express').Router();
const createClient = require('twilio');

router.post('/sendMessage', (req, res) => {
  try {
    const client = createClient(process.env.accountSid, process.env.authToken);
    const { 
      phone,
      customerName,
      data: {
        authCodeText,
        providerReferralText,
      } }= req.body;
  
    if (!customerName) {
      res.json({
        status: "validationError",
        message: "Customer Name missing."
      });
      return;
    }
  
    client.messages
    .create({
       body: getMessageBody(customerName, authCodeText, providerReferralText),
       from: process.env.phoneNo,
       to: phone
     })
    .then(message => {
      const { sid } = message;
      res.send(sid);
    });
  } catch (ex) {
    res.json(ex);
  }
});

const getMessageBody = (customerName ,authCode, providerReferralText) => {
  if (!authCode && !providerReferralText) throw new Error("Invalid authcode and text");
  if (authCode && !providerReferralText) {
    return `Here is your code: ${authCode}.
    Questions? Call the number on the back of your ID card.
    Click for disclosures:
    Link1
    Link2`;
  }

  if (!authCode && providerReferralText) {
    return `Here are your providers:
    ${providerReferralText}
    Questions? Call the number on the back of your ID card.
    Click for disclosures:
    Link1
    Link2`;
  }

    return `Here is your code: ${authCode}.
    Here are your providers:
    ${providerReferralText}
    Questions? Call the number on the back of your ID card.
    Click for disclosures:
    Link1
    Link2`;
};


module.exports = router;